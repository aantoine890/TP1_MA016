#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif

#define CGLTF_IMPLEMENTATION
#include "../extern/cgltf.h"

#define FAST_OBJ_IMPLEMENTATION
#include "../extern/fast_obj.h"
