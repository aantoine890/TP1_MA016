#include "mesh.h"

void meshopt_optimize(MBuf& data, const Mesh& mesh);

