#include "mesh.h"

void meshopt_statistics(const char *name, const MBuf& data, const Mesh& mesh);


