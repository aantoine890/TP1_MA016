#include <stdio.h>
#include "mesh.h"

int load_obj(const char *filename, MBuf& data, Mesh& mesh);
int load_ply(const char* filename, MBuf &data, Mesh &mesh);

