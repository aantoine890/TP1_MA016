#include <GL/gl.h>

GLint create_shader(const char *vs_path, const char *fs_path);
