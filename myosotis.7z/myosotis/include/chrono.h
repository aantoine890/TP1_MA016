#pragma once

void timer_start();
unsigned int timer_stop(const char *str = "");

